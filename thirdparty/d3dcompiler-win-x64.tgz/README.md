# d3dcompiler-win-x64

Legacy HLSL compiler (FXC / D3DCompile API) for the DXBC backend, vendored from a
locally installed Windows 10 SDK.

- Source SDK: Windows 10 SDK **10.0.19041.0**
  (`C:\Program Files (x86)\Windows Kits\10`)
- `bin/x64/d3dcompiler_47.dll` — taken from `Redist\D3D\x64\d3dcompiler_47.dll`.
  This DLL lives under the SDK's *Redist* directory: Microsoft explicitly licenses
  it for redistribution with applications (see the Windows SDK license,
  "Distributable Code" / REDIST.TXT list, which includes d3dcompiler_47.dll).
- `lib/x64/d3dcompiler.lib` — import library from `Lib\10.0.19041.0\um\x64`.
- `inc/d3dcompiler.h`, `inc/d3d11shader.h`, `inc/d3dcommon.h` — from
  `Include\10.0.19041.0\um`. Headers are used for building against the API and are
  not themselves redistributed to end users.

Layout:

```
bin/x64/d3dcompiler_47.dll
lib/x64/d3dcompiler.lib
inc/d3dcompiler.h
inc/d3d11shader.h
inc/d3dcommon.h
README.md
```
